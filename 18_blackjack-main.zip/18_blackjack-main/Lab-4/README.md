# Lab 4 – Vibe Coding (Blackjack) – Sasyak Subudhi, PES1UG24AM256

| Deliverable | File |
|---|---|
| Video before changes | `before_gameplay.mp4` |
| Video after changes | `after_gameplay.mp4` |
| Updated code | `code/` (same as the repo root; the per-task commit history is in `git log`) |
| Chat history | `chat_history.pdf` |

Run: `python main.py` — Tests: `python -m unittest discover -s tests` (69 tests).
