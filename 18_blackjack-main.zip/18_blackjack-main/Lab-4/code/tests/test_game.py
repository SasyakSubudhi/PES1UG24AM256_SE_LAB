import unittest

from cards import Deck
from game import Blackjack


def decks(*hands):
    """Each argument is a list of ranks for one round (player, player, dealer, dealer, draws...)."""
    it = iter(hands)
    return lambda: Deck([(r, "S") for r in next(it)])


def play(inputs, rounds, chips=100):
    """Run a whole session with scripted input; returns (game, printed lines)."""
    script, out = iter(inputs), []

    def fake_input(prompt=""):
        out.append(prompt)
        try:
            return next(script)
        except StopIteration:
            raise AssertionError("game asked for more input than the test provided")

    g = Blackjack(chips=chips, input_fn=fake_input, print_fn=out.append, deck_factory=decks(*rounds))
    g.run()
    return g, out


WIN = ["10", "9", "10", "7"]        # player 19 vs dealer 17 -> win on stand
LOSE = ["10", "7", "10", "9"]       # 17 vs 19 -> lose on stand
PUSH = ["10", "8", "9", "9"]        # 18 vs 18
NATURAL = ["A", "K", "9", "8"]


class WagerTests(unittest.TestCase):
    def test_win_adds_wager(self):
        g, _ = play(["20", "s", "n"], [WIN])
        self.assertEqual(g.chips, 120)

    def test_loss_subtracts_wager(self):
        g, _ = play(["20", "s", "n"], [LOSE])
        self.assertEqual(g.chips, 80)

    def test_push_returns_wager(self):
        g, _ = play(["20", "s", "n"], [PUSH])
        self.assertEqual(g.chips, 100)

    def test_blackjack_pays_three_to_two(self):
        g, _ = play(["20", "n"], [NATURAL])
        self.assertEqual(g.chips, 130)

    def test_round_settles_exactly_once(self):
        g, _ = play(["10", "s", "n"], [WIN])
        self.assertEqual(g.chips, 110)   # not 120

    def test_chips_persist_across_rounds(self):
        g, _ = play(["10", "s", "y", "30", "s", "y", "5", "s", "n"], [WIN, LOSE, WIN])
        self.assertEqual(g.chips, 100 + 10 - 30 + 5)

    def test_bet_all_chips_and_lose_ends_game(self):
        g, out = play(["100", "s"], [LOSE])          # no "play again" prompt expected
        self.assertEqual(g.chips, 0)
        self.assertTrue(any("out of chips" in line.lower() for line in out))

    def test_can_bet_exactly_remaining_chips_and_double_up(self):
        g, _ = play(["100", "s", "n"], [WIN])
        self.assertEqual(g.chips, 200)


class InvalidWagerTests(unittest.TestCase):
    BAD = ["abc", "0", "-5", "5.5", "", "   ", "101", "1e2", "+5", "1_0", "٣", "10 20", "0x10"]

    def test_invalid_wagers_never_change_bankroll_or_start_a_round(self):
        for bad in self.BAD:
            with self.subTest(wager=bad):
                # an invalid wager is rejected, then the player quits at the wager prompt
                g, out = play([bad, "q"], [])
                self.assertEqual(g.chips, 100)
                self.assertTrue(any("wager" in str(l).lower() for l in out if "Chips:" not in str(l)))

    def test_valid_wager_accepted_after_invalid_ones(self):
        g, _ = play(["abc", "0", "999", "10", "s", "n"], [WIN])
        self.assertEqual(g.chips, 110)

    def test_wager_with_surrounding_spaces_is_ok(self):
        g, _ = play([" 15 ", "s", "n"], [WIN])
        self.assertEqual(g.chips, 115)

    def test_wager_limited_to_current_bankroll(self):
        g, out = play(["50", "s", "y", "51", "q"], [LOSE], chips=100)   # 50 left; 51 is too much
        self.assertEqual(g.chips, 50)
        self.assertTrue(any("between 1 and 50" in str(l) for l in out))


class QuitTests(unittest.TestCase):
    def test_quit_at_wager_prompt(self):
        g, _ = play(["q"], [])
        self.assertEqual(g.chips, 100)

    def test_quit_mid_round_returns_wager(self):
        g, _ = play(["40", "q"], [["5", "6", "10", "7"]])
        self.assertEqual(g.chips, 100)

    def test_decline_to_play_again(self):
        g, _ = play(["10", "s", "n"], [WIN])
        self.assertEqual(g.chips, 110)


if __name__ == "__main__":
    unittest.main()
