import unittest

from cards import Deck, hand_value


def hand(*ranks):
    """Build a hand from ranks, e.g. hand("A", "9") (suits do not matter for scoring)."""
    return [(r, "S") for r in ranks]


class HandValueTests(unittest.TestCase):
    # --- Task 1 examples from the README ---
    def test_ace_plus_nine_is_20(self):
        self.assertEqual(hand_value(hand("A", "9")), 20)

    def test_ace_nine_five_is_15(self):
        self.assertEqual(hand_value(hand("A", "9", "5")), 15)

    def test_ace_ace_nine_is_21(self):
        self.assertEqual(hand_value(hand("A", "A", "9")), 21)

    # --- extra edge cases ---
    def test_blackjack_is_21(self):
        self.assertEqual(hand_value(hand("A", "K")), 21)
        self.assertEqual(hand_value(hand("10", "A")), 21)

    def test_two_aces_is_12(self):
        self.assertEqual(hand_value(hand("A", "A")), 12)

    def test_four_aces_is_14(self):
        self.assertEqual(hand_value(hand("A", "A", "A", "A")), 14)

    def test_ace_flips_to_one_when_needed(self):
        self.assertEqual(hand_value(hand("A", "6")), 17)          # soft 17
        self.assertEqual(hand_value(hand("A", "6", "10")), 17)    # becomes hard 17

    def test_multiple_aces_only_downgrade_as_needed(self):
        self.assertEqual(hand_value(hand("A", "A", "8")), 20)     # 11 + 1 + 8
        self.assertEqual(hand_value(hand("A", "A", "K")), 12)     # 1 + 1 + 10
        self.assertEqual(hand_value(hand("A", "5", "A", "4")), 21)

    def test_bust_without_aces(self):
        self.assertEqual(hand_value(hand("K", "Q", "5")), 25)

    def test_bust_with_aces_still_reports_over_21(self):
        self.assertEqual(hand_value(hand("A", "K", "Q")), 21)
        self.assertEqual(hand_value(hand("A", "K", "Q", "2")), 23)

    def test_face_cards_and_ten(self):
        self.assertEqual(hand_value(hand("J", "Q")), 20)
        self.assertEqual(hand_value(hand("K", "10")), 20)

    def test_empty_hand_is_zero(self):
        self.assertEqual(hand_value([]), 0)


class DeckTests(unittest.TestCase):
    def test_deck_has_52_unique_cards(self):
        d = Deck()
        self.assertEqual(len(d.cards), 52)
        self.assertEqual(len(set(d.cards)), 52)


if __name__ == "__main__":
    unittest.main()
