import random
import unittest

import game
from cards import Deck, EmptyDeckError
from game import Blackjack, Round, RoundOverError
from tests.test_game import LOSE, NATURAL, WIN, play


class EmptyDeckTests(unittest.TestCase):
    def test_draw_from_empty_deck_raises(self):
        d = Deck()
        for _ in range(52):
            d.draw()
        with self.assertRaises(EmptyDeckError):
            d.draw()

    def test_full_deck_can_be_drawn_completely_without_repeats(self):
        d = Deck()
        cards = [d.draw() for _ in range(52)]
        self.assertEqual(len(set(cards)), 52)
        self.assertEqual(len(d), 0)

    def test_deck_empty_when_dealing_cancels_round(self):
        g, out = play(["25", "n"], [[]])               # no cards at all
        self.assertEqual(g.chips, 100)
        self.assertTrue(any("ran out of cards" in str(l) for l in out))

    def test_deck_runs_out_when_player_hits(self):
        g, out = play(["25", "h", "n"], [["5", "6", "10", "7"]])   # only the 4 dealt cards
        self.assertEqual(g.chips, 100)
        self.assertTrue(any("ran out of cards" in str(l) for l in out))

    def test_deck_runs_out_during_dealer_draw(self):
        g, out = play(["25", "s", "n"], [["10", "8", "2", "3"]])   # dealer 5 must draw, none left
        self.assertEqual(g.chips, 100)
        self.assertTrue(any("ran out of cards" in str(l) for l in out))

    def test_cancelled_round_cannot_be_settled_or_continued(self):
        r = Round(Deck([("5", "S"), ("6", "S"), ("10", "S"), ("7", "S")]))
        with self.assertRaises(EmptyDeckError):
            r.hit()
        self.assertEqual(len(r.player), 2)             # failed draw left no half-state
        r.cancel()
        for action in (r.hit, r.stand, lambda: r.settle(10)):
            with self.assertRaises(RoundOverError):
                action()
        self.assertFalse(r.settled)


class InvalidCommandTests(unittest.TestCase):
    def test_invalid_commands_do_not_change_state_or_bankroll(self):
        for bad in ["x", "", "   ", "hit", "stand", "1", "hh", "!", "yes"]:
            with self.subTest(cmd=bad):
                g, out = play(["20", bad, "s", "n"], [WIN])
                self.assertEqual(g.chips, 120)               # exactly one settlement
                self.assertTrue(any("Invalid command" in str(l) for l in out))

    def test_commands_are_case_insensitive_and_trimmed(self):
        g, _ = play(["20", "  S ", "N"], [WIN])
        self.assertEqual(g.chips, 120)

    def test_repeated_stand_after_round_end_does_not_resettle(self):
        # the extra "s" answers the "Play again?" prompt, is rejected, and the game carries on
        g, out = play(["10", "s", "s", "s", "n"], [WIN])
        self.assertEqual(g.chips, 110)
        self.assertEqual(sum("Invalid answer" in str(l) for l in out), 2)

    def test_repeated_hit_after_bust_does_not_change_chips_again(self):
        g, _ = play(["10", "h", "h", "h", "n"], [["10", "6", "5", "4", "K"]])
        self.assertEqual(g.chips, 90)                         # busted once, lost once

    def test_actions_blocked_after_natural(self):
        g, out = play(["20", "h", "n"], [NATURAL])           # "h" lands on the play-again prompt
        self.assertEqual(g.chips, 130)
        self.assertTrue(any("Invalid answer" in str(l) for l in out))

    def test_play_again_rejects_garbage_then_accepts(self):
        g, _ = play(["10", "s", "maybe", "", "y", "10", "s", "n"], [WIN, WIN])
        self.assertEqual(g.chips, 120)


class FeedbackTests(unittest.TestCase):
    def test_hit_reports_the_card_drawn(self):
        _, out = play(["10", "h", "q"], [["5", "6", "10", "7", "3", "K"]])
        self.assertIn("You draw 3S.", out)

    def test_dealer_draws_are_reported(self):
        _, out = play(["10", "s", "n"], [["10", "8", "2", "3", "4", "5", "K"]])
        draws = [l for l in out if str(l).startswith("Dealer draws")]
        self.assertEqual(draws, ["Dealer draws 4S.", "Dealer draws 5S.", "Dealer draws KS."])

    def test_outcome_messages_include_chip_change(self):
        _, out = play(["20", "s", "n"], [WIN])
        self.assertIn("Player wins. (+20 chips)", out)
        _, out = play(["20", "s", "n"], [LOSE])
        self.assertIn("Dealer wins. (-20 chips)", out)
        _, out = play(["20", "s", "n"], [["10", "8", "9", "9"]])
        self.assertIn("Push. Wager returned.", out)
        _, out = play(["20", "n"], [NATURAL])
        self.assertIn("Blackjack! Player wins. (+30 chips)", out)

    def test_bust_message(self):
        _, out = play(["10", "h", "n"], [["10", "6", "5", "4", "K"]])
        self.assertIn("Bust. Dealer wins. (-10 chips)", out)

    def test_dealer_hand_revealed_when_round_ends(self):
        _, out = play(["10", "s", "n"], [WIN])
        self.assertIn("Dealer: 10S 7S", out)


class QuitAndInputEndTests(unittest.TestCase):
    def test_quit_at_each_prompt(self):
        for script in (["q"], ["10", "q"], ["10", "s", "n"]):
            with self.subTest(script=script):
                g, _ = play(script, [WIN])
                self.assertIn(g.chips, (100, 110))
                self.assertGreaterEqual(g.chips, 100)

    def test_end_of_input_mid_round_is_handled(self):
        def eof_input(prompt=""):
            out.append(prompt)
            if len(out) > 3:
                raise EOFError
            return "10"
        out = []
        g = Blackjack(input_fn=eof_input, print_fn=out.append,
                      deck_factory=lambda: Deck([(r, "S") for r in ["5", "6", "10", "7"]]))
        g.run()                                  # must not raise
        self.assertEqual(g.chips, 100)

    def test_keyboard_interrupt_is_handled(self):
        def ctrl_c(prompt=""):
            raise KeyboardInterrupt
        g = Blackjack(input_fn=ctrl_c, print_fn=lambda *_: None)
        g.run()
        self.assertEqual(g.chips, 100)


class FuzzTests(unittest.TestCase):
    """Throw random keystrokes at whole sessions: no crash, bankroll stays a sane integer."""

    TOKENS = ["h", "s", "q", "y", "n", "1", "5", "10", "50", "100", "0", "-3", "abc", "", " ", "2.5", "H", "S"]

    def test_random_sessions(self):
        for seed in range(400):
            rng = random.Random(seed)
            random.seed(seed)                            # real shuffled decks
            budget = [rng.randint(1, 60)]

            def fake_input(prompt=""):
                budget[0] -= 1
                return rng.choice(self.TOKENS) if budget[0] > 0 else "q"

            g = Blackjack(input_fn=fake_input, print_fn=lambda *_: None)
            g.run()
            self.assertIsInstance(g.chips, int, f"seed {seed}")
            self.assertGreaterEqual(g.chips, 0, f"seed {seed}")


if __name__ == "__main__":
    unittest.main()
