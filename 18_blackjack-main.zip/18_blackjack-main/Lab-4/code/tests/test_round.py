import unittest

import game
from cards import Deck, is_blackjack
from game import Round, RoundOverError


def rig(*ranks):
    """A deck that deals the given ranks in order: player, player, dealer, dealer, then draws."""
    return Deck([(r, "S") for r in ranks])


class NaturalTests(unittest.TestCase):
    def test_is_blackjack_needs_exactly_two_cards(self):
        self.assertTrue(is_blackjack([("A", "S"), ("K", "H")]))
        self.assertFalse(is_blackjack([("A", "S"), ("5", "H"), ("5", "D")]))  # 21 in 3 cards
        self.assertFalse(is_blackjack([("10", "S"), ("9", "H")]))

    def test_player_blackjack_ends_round_and_pays_3_to_2(self):
        r = Round(rig("A", "K", "9", "8"))
        self.assertTrue(r.over)
        self.assertEqual(r.outcome, game.BLACKJACK)
        self.assertEqual(r.payout(10), 15)
        self.assertEqual(r.payout(20), 30)
        self.assertEqual(r.payout(5), 7)  # whole chips only: 7.5 rounds down

    def test_dealer_blackjack_beats_normal_player_hand(self):
        r = Round(rig("10", "9", "A", "Q"))
        self.assertTrue(r.over)
        self.assertEqual(r.outcome, game.DEALER_BLACKJACK)
        self.assertEqual(r.payout(10), -10)

    def test_both_blackjack_is_push(self):
        r = Round(rig("A", "K", "A", "Q"))
        self.assertEqual(r.outcome, game.PUSH)
        self.assertEqual(r.payout(10), 0)

    def test_three_card_21_is_not_blackjack(self):
        r = Round(rig("5", "5", "9", "8", "A"))   # player 10, hits A -> 21 (3 cards)
        r.hit()
        self.assertEqual(r.outcome, game.WIN)         # auto-stand, 21 beats dealer 17
        self.assertNotEqual(r.outcome, game.BLACKJACK)  # so it pays 1:1, not 3:2
        self.assertEqual(r.payout(10), 10)


class PlayerActionTests(unittest.TestCase):
    def test_player_bust_ends_round_without_dealer_drawing(self):
        r = Round(rig("10", "6", "5", "4", "K"))   # dealer 9 would normally draw
        r.hit()
        self.assertTrue(r.over)
        self.assertEqual(r.outcome, game.BUST)
        self.assertEqual(len(r.dealer), 2)
        self.assertEqual(r.payout(10), -10)

    def test_ace_prevents_bust_on_hit(self):
        r = Round(rig("A", "9", "10", "7", "5"))   # A+9 = 20, hit 5 -> A+9+5 = 15, not a bust
        r.hit()
        self.assertFalse(r.over)

    def test_reaching_21_auto_stands(self):
        r = Round(rig("5", "6", "10", "7", "10"))  # 11 + 10 = 21; dealer 17 stands
        r.hit()
        self.assertTrue(r.over)
        self.assertEqual(r.outcome, game.WIN)

    def test_actions_after_round_over_are_rejected(self):
        r = Round(rig("10", "6", "5", "4", "K"))
        r.hit()  # bust
        with self.assertRaises(RoundOverError):
            r.hit()
        with self.assertRaises(RoundOverError):
            r.stand()
        self.assertEqual(len(r.player), 3)         # nothing was drawn by the rejected actions

    def test_actions_after_stand_are_rejected(self):
        r = Round(rig("10", "8", "10", "7"))
        r.stand()
        with self.assertRaises(RoundOverError):
            r.stand()
        with self.assertRaises(RoundOverError):
            r.hit()

    def test_actions_after_natural_are_rejected(self):
        r = Round(rig("A", "K", "9", "8"))
        with self.assertRaises(RoundOverError):
            r.hit()
        with self.assertRaises(RoundOverError):
            r.stand()


class DealerRuleTests(unittest.TestCase):
    def test_dealer_draws_until_17_or_more(self):
        r = Round(rig("10", "9", "2", "3", "4", "5", "K"))   
        r.stand()
        # dealer: 2+3=5, draws 4 -> 9, draws 5 -> 14, draws K -> 24 -> bust
        self.assertEqual([c[0] for c in r.dealer_draws], ["4", "5", "K"])
        self.assertEqual(r.outcome, game.DEALER_BUST)

    def test_dealer_stops_at_17(self):
        r = Round(rig("10", "9", "10", "7", "5"))    # dealer 17 must not draw
        r.stand()
        self.assertEqual(r.dealer_draws, [])
        self.assertEqual(r.outcome, game.WIN)         # 19 vs 17

    def test_dealer_stands_on_soft_17(self):
        r = Round(rig("10", "8", "A", "6", "5"))      # dealer A+6 = soft 17
        r.stand()
        self.assertEqual(r.dealer_draws, [])
        self.assertEqual(r.outcome, game.WIN)

    def test_dealer_draws_on_16_and_ace_counts_as_one_if_needed(self):
        r = Round(rig("10", "8", "10", "6", "A"))     # 16 + A = 17 -> stands
        r.stand()
        self.assertEqual(len(r.dealer), 3)
        self.assertEqual(r.outcome, game.WIN)         # 18 vs 17

    def test_dealer_bust_pays_player(self):
        r = Round(rig("10", "2", "10", "6", "K"))     # dealer 16 + K = 26
        r.stand()
        self.assertEqual(r.outcome, game.DEALER_BUST)
        self.assertEqual(r.payout(10), 10)

    def test_dealer_with_higher_total_wins(self):
        r = Round(rig("10", "8", "10", "9"))
        r.stand()
        self.assertEqual(r.outcome, game.LOSE)
        self.assertEqual(r.payout(10), -10)

    def test_push_on_equal_totals(self):
        r = Round(rig("10", "8", "9", "9"))
        r.stand()
        self.assertEqual(r.outcome, game.PUSH)
        self.assertEqual(r.payout(10), 0)


class SettlementTests(unittest.TestCase):
    def test_settle_only_once(self):
        r = Round(rig("10", "9", "10", "7"))
        r.stand()
        self.assertEqual(r.settle(10), 10)
        with self.assertRaises(RoundOverError):
            r.settle(10)

    def test_cannot_settle_unfinished_round(self):
        r = Round(rig("5", "6", "10", "7"))
        with self.assertRaises(RoundOverError):
            r.settle(10)
        self.assertFalse(r.settled)


if __name__ == "__main__":
    unittest.main()
