import random

RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
SUITS = ["C", "D", "H", "S"]


class EmptyDeckError(Exception):
    """Raised when a card is drawn from a deck with no cards left."""


class Deck:
    def __init__(self, cards=None):
        """A shuffled 52-card deck, or a fixed deck for testing.

        When `cards` is given it is used as-is and cards are drawn in the order listed.
        """
        if cards is None:
            self.cards = [(rank, suit) for suit in SUITS for rank in RANKS]
            random.shuffle(self.cards)
        else:
            self.cards = list(reversed(cards))  # draw() pops from the end

    def __len__(self):
        return len(self.cards)

    def draw(self):
        if not self.cards:
            raise EmptyDeckError("The deck is empty.")
        return self.cards.pop()


def card_points(rank):
    """Base point value of one card: Ace is 11 here, face cards 10, others face value."""
    if rank == "A":
        return 11
    if rank in {"J", "Q", "K"}:
        return 10
    return int(rank)


def hand_value(hand):
    """Best blackjack total for a hand.

    Every Ace starts as 11; while the hand is over 21, one Ace at a time is
    downgraded to 1 (subtract 10) until the hand fits or no 11-valued Ace is left.
    """
    total = sum(card_points(rank) for rank, _ in hand)
    soft_aces = sum(1 for rank, _ in hand if rank == "A")
    while total > 21 and soft_aces:
        total -= 10
        soft_aces -= 1
    return total


def is_blackjack(hand):
    """A natural: exactly two cards totalling 21 (Ace + ten-valued card)."""
    return len(hand) == 2 and hand_value(hand) == 21
