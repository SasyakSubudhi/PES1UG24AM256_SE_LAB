from cards import Deck, EmptyDeckError, hand_value, is_blackjack

# Round outcomes
BLACKJACK = "blackjack"            # player natural, dealer has none
DEALER_BLACKJACK = "dealer_blackjack"
BUST = "bust"                      # player went over 21
DEALER_BUST = "dealer_bust"
WIN = "win"                        # higher total, no bust
LOSE = "lose"
PUSH = "push"

MESSAGES = {
    BLACKJACK: "Blackjack! Player wins.",
    DEALER_BLACKJACK: "Dealer has blackjack. Dealer wins.",
    BUST: "Bust. Dealer wins.",
    DEALER_BUST: "Dealer busts. Player wins.",
    WIN: "Player wins.",
    LOSE: "Dealer wins.",
    PUSH: "Push.",
}


class RoundOverError(Exception):
    """Raised when someone tries to act on a round that has already ended."""


class Round:
    """One hand of blackjack: deal, player actions, dealer play and resolution.

    Rules: the dealer draws until reaching 17 or more and stands on every 17
    (including soft 17). A natural blackjack ends the round immediately
    and pays 3:2; if both sides have one it is a push.
    """

    def __init__(self, deck=None):
        self.deck = deck if deck is not None else Deck()
        self.player = [self.deck.draw(), self.deck.draw()]
        self.dealer = [self.deck.draw(), self.deck.draw()]
        self.dealer_draws = []
        self.over = False
        self.outcome = None
        self.settled = False
        self.cancelled = False
        self._check_naturals()

    # -- state changes -------------------------------------------------
    def _finish(self, outcome):
        self.over = True
        self.outcome = outcome

    def _require_active(self):
        if self.over:
            raise RoundOverError("The round is already over.")

    def _check_naturals(self):
        player_nat, dealer_nat = is_blackjack(self.player), is_blackjack(self.dealer)
        if player_nat and dealer_nat:
            self._finish(PUSH)
        elif player_nat:
            self._finish(BLACKJACK)
        elif dealer_nat:
            self._finish(DEALER_BLACKJACK)

    def cancel(self):
        """Void the round (e.g. the deck ran out). A cancelled round is never settled."""
        self.over = True
        self.cancelled = True
        self.outcome = None

    def hit(self):
        """Player takes one card. Busting ends the round; reaching 21 stands automatically."""
        self._require_active()
        card = self.deck.draw()
        self.player.append(card)
        total = hand_value(self.player)
        if total > 21:
            self._finish(BUST)
        elif total == 21:
            self.stand()
        return card

    def stand(self):
        """Player stands: the dealer plays out the hand and the round is resolved."""
        self._require_active()
        while hand_value(self.dealer) < 17:
            card = self.deck.draw()
            self.dealer.append(card)
            self.dealer_draws.append(card)
        player_total, dealer_total = hand_value(self.player), hand_value(self.dealer)
        if dealer_total > 21:
            self._finish(DEALER_BUST)
        elif player_total > dealer_total:
            self._finish(WIN)
        elif player_total < dealer_total:
            self._finish(LOSE)
        else:
            self._finish(PUSH)

    # -- money ---------------------------------------------------------
    def payout(self, bet):
        """Net chip change for `bet` given the finished round's outcome."""
        if self.cancelled:
            raise RoundOverError("The round was cancelled; there is nothing to pay.")
        if not self.over:
            raise RoundOverError("The round is not finished yet.")
        if self.outcome == BLACKJACK:
            return bet * 3 // 2
        if self.outcome in (WIN, DEALER_BUST):
            return bet
        if self.outcome in (LOSE, BUST, DEALER_BLACKJACK):
            return -bet
        return 0  # push

    def settle(self, bet):
        """Return the net chip change. A round can be settled exactly once."""
        if self.settled:
            raise RoundOverError("This round has already been settled.")
        delta = self.payout(bet)
        self.settled = True
        return delta


def fmt(card):
    return f"{card[0]}{card[1]}"


DECK_EMPTY_MESSAGE = "The deck ran out of cards. Round cancelled; your wager is returned."


def parse_wager(text, chips):
    """Validate a wager string and return it as an int.

    Accepts only a plain whole number from 1 up to the chips available.
    Raises ValueError with a user-facing message otherwise.
    """
    text = text.strip()
    if not (text.isascii() and text.isdecimal()):
        raise ValueError(f"Invalid wager {text!r}. Enter a whole number of chips.")
    bet = int(text)
    if bet < 1 or bet > chips:
        raise ValueError(f"Wager must be between 1 and {chips} chips.")
    return bet


class Blackjack:
    START_CHIPS = 100

    def __init__(self, chips=START_CHIPS, input_fn=input, print_fn=print, deck_factory=Deck):
        self.chips = chips
        self.input = input_fn
        self.print = print_fn
        self.deck_factory = deck_factory

    def show(self, player, dealer, hide=True):
        shown_dealer = ["??"] if hide else [fmt(c) for c in dealer]
        self.print("Dealer: " + " ".join(shown_dealer))
        self.print("Player: " + " ".join(fmt(c) for c in player)
                   + f" = {hand_value(player)}")

    def ask_bet(self):
        """Prompt until a valid wager is entered. Returns None if the player quits.

        Nothing about the bankroll changes until a round is actually played and settled.
        """
        while True:
            raw = self.input(f"Chips: {self.chips}. Wager 1-{self.chips} [q]uit: ")
            if raw.strip().lower() == "q":
                return None
            try:
                return parse_wager(raw, self.chips)
            except ValueError as err:
                self.print(str(err))

    def say_dealer_draws(self, rnd):
        for card in rnd.dealer_draws:
            self.print(f"Dealer draws {fmt(card)}.")

    def ask_yes_no(self, prompt):
        """Ask until the answer is y/yes or n/no/q; anything else is rejected and re-asked."""
        while True:
            answer = self.input(prompt).strip().lower()
            if answer in ("y", "yes"):
                return True
            if answer in ("n", "no", "q", "quit"):
                return False
            self.print(f"Invalid answer {answer!r}. Please type y or n.")

    def round(self):
        """Play one round. Returns False if the player quit, True otherwise."""
        bet = self.ask_bet()
        if bet is None:
            return False
        try:
            rnd = Round(self.deck_factory())
        except EmptyDeckError:
            self.print(DECK_EMPTY_MESSAGE)
            return True
        self.show(rnd.player, rnd.dealer, hide=not rnd.over)

        try:
            while not rnd.over:
                key = self.input("[h]it [s]tand [q]uit: ").strip().lower()
                if key == "q":
                    self.print("Round abandoned; your wager is returned.")
                    return False
                if key == "h":
                    self.print(f"You draw {fmt(rnd.hit())}.")
                elif key == "s":
                    self.print(f"You stand on {hand_value(rnd.player)}.")
                    rnd.stand()
                else:
                    self.print(f"Invalid command {key!r}. Use h, s or q.")
                    continue
                self.say_dealer_draws(rnd)
                self.show(rnd.player, rnd.dealer, hide=not rnd.over)
        except EmptyDeckError:
            rnd.cancel()
            self.print(DECK_EMPTY_MESSAGE)
            return True

        delta = rnd.settle(bet)         # settle() refuses a second call
        self.chips += delta
        suffix = f" ({delta:+d} chips)" if delta else " Wager returned."
        self.print(MESSAGES[rnd.outcome] + suffix)
        self.print(f"Chips: {self.chips}")
        return True

    def run(self):
        self.print(f"Blackjack — starting chips: {self.chips}")
        try:
            while self.chips > 0:
                if not self.round():
                    return
                if self.chips <= 0:
                    break
                if not self.ask_yes_no("Play again? [y/n]: "):
                    return
            self.print("You are out of chips. Game over.")
        except (EOFError, KeyboardInterrupt):
            self.print(f"\nInput ended. Leaving the table with {self.chips} chips.")
